图标运行方法
服务器端点击Server.jar
客户端点击Texas.jar

命令行运行方法
在服务器端目录下打开命令行
>>>java -cp "json-simple-1.1.jar;sqlite-jdbc-3.30.1.jar" -jar Server.jar

在用户端目录下开启命令行
>>>java -cp "json-simple-1.1.jar" -jar Texas.jar
